<?php
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASSWORD', '');
    define('DB_DATABASE', 'rms');
    define('APP_NAME', 'Pathfinder Hotel');
    error_reporting(1);
?>