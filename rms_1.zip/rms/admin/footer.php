<div id="footer">
<div class="bottom_addr">&copy; <?php echo date('Y'); ?> Pathfinder Hotel Restaurant. All Rights Reserved</div>
</div>